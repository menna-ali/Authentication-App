<html>
<head></head>
<body>
<p><?php echo e($title); ?></p>
<div>
            Thank you for creating an account with the Authentication App.
            Please follow the link below to verify your email address: <br></br> <br></br>
            <?php echo e(URL::to('register/verify/' . $confirmation_code)); ?>.<br></br><br></br><br></br>

            Authentication App Team.

</div>

</body>
</html>
