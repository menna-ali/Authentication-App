<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Flash;
use App\User;
use Redirect;

class RegistrationController extends Controller
{
  public function confirm($confirmation_code)
  {
      if( ! $confirmation_code)
      {
          return Redirect::to('resend');
      }

      $user = User::whereConfirmationCode($confirmation_code)->first();

      if ( ! $user)
      {
        return Redirect::to('register')
        ->withErrors([ "firstname" => "Please complete your registration first"]);

      }

      $user->confirmed = 1;
      $user->confirmation_code = null;
      $user->save();

      return Redirect::to('verified');
  }
}
