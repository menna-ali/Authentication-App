<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use Auth;
use App\User;
use Validator;
use Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Controllers\EmailController;
use Mail;
use Session;

class HomeController extends Controller
{

  /**
  * Show the application dashboard.
  *
  * @return \Illuminate\Http\Response
  */
  public function showLogin()
  {
    return view('login');
  }

  public function doLogin(Request $request)
  {
    $userdata = array(
      'email'     => $request->input('email'),
      'password'  => $request->input('password'),
      'confirmed' => 1);

      if(Auth::attempt($userdata))
      {
        return view('home');
      }

      else {
        return Redirect::to('login')
        ->withErrors([ "email" => "These credentials do not match our records."])
        ->withInput(Input::except('password'));
      }
    }

    public function showRegister()
    {
      return view('register');
    }

    public function showResend()
    {
      return view('resend');
    }

    public function doRegister(Request $request)
    {

      $rules = array ('firstname' => 'required|max:255',
      'lastname' => 'required|max:255',
      'email' => 'required|email|max:255|unique:users',
      'password' => 'required|min:6|confirmed');

      $userdata = array(
        'firstname' => $request->input('firstname'),
        'lastname' => $request->input('lastname'),
        'email'     => $request->input('email'),
        'password'  => $request->input('password'));

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
          return Redirect::to('register')
          ->withErrors($validator)
          ->withInput(Input::except('password'));
        }

          $confirmation_code = str_random(30).time();

          $user = User::create([
            'firstname' => $userdata['firstname'],
            'lastname' => $userdata['lastname'],
            'email' => $userdata['email'],
            'password' => bcrypt($userdata['password']),
            'confirmation_code' => $confirmation_code,
          ]);


          Session::flash('email', $request->input('email'));
          Session::flash('name', $request->input('firstname'));
          Session::flash('code', $confirmation_code);

          return Redirect::to('send');

      }

      public function showHome()
      {
        if (Auth::user() == null)
        {
          return view('login');
        }
        else {
          return view('home');
        }
      }

      public function doLogout()
      {
        Auth::logout();
        return view('login');
      }

      public function send()
      {

          $details = array(
          'title'  => 'Dear '.Session::get('name').',',
          'code' => Session::get('code'));
          $title = $details['title'];
          $code = $details['code'];

          Mail::send('send', ['title' => $title, 'confirmation_code' => $code], function ($message)
          {
            $message->from('verify@authapp.com', 'Authentication App');

            $message->to(Session::get('email'));

            $message->subject('Verify your account - Auth App');

          });

          return view('confirm');

        }

        public function doResend(Request $request)
        {
            $user = User::whereEmail($request->input('email'))->first();
            $confirm_code = str_random(30).time();
            $user->confirmation_code = $confirm_code;
            $user->save();

            $details = array(
            'title'  => 'Dear '.$user->firstname.',',
            'code' => $confirm_code);
            $title = $details['title'];
            $code = $details['code'];
            Session::flash('remail', $request->input('email'));

            Mail::send('send', ['title' => $title, 'confirmation_code' => $code], function ($message)
            {
              $message->from('verify@authapp.com', 'Authentication App');

              $message->to(Session::get('remail'));

              $message->subject('Verify your account - Auth App');

            });
            Session::forget('remail');

            return view('confirm');

          }
      }
