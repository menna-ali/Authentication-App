<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Mail;
use Session;

class EmailController extends Controller
{
  public function send()
  {
    $details = array(
    'name' => 'Dear '.Session::get('firstname').',',
    'title'  => 'Please visit our website to login and verify your account.
    http://localhost:8000/login',
     'content' => 'content');

    $name = $details['name'];
    $title = $details['title'];
    $content = $details['content'];

    Mail::send('send', ['name' => $name, 'title' => $title, 'content' => $content], function ($message)
    {

        $message->from('verify@authapp.com', 'Authentication App');

        $message->to(Session::get('email'));

        $message->subject('Verify your account - Auth App');

    });

        return view('confirm');

  }
}
