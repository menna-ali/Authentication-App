<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', 'HomeController@showLogin');

Route::post('/login', 'HomeController@doLogin');

Route::get('/register', 'HomeController@showRegister');

Route::post('/register', 'HomeController@doRegister');

Route::get('/home', 'HomeController@showHome');

Route::get('/logout','HomeController@doLogout');

Route::get('/send', 'HomeController@send');

Route::get('/confirm', function () {
    return view('confirm');
});

Route::get('/verified', function () {
    return view('verified');
});

Route::get('/register/verify/{confirmationCode}', [
    'as' => 'confirmation_path',
    'uses' => 'RegistrationController@confirm'
]);

Route::get('/resend', 'HomeController@showResend');

Route::post('/resend', 'HomeController@doResend');
